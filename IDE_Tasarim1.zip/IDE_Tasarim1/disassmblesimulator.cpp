#include "disassmblesimulator.h"
#include "ui_disassmblesimulator.h"

DisassmbleSimulator::DisassmbleSimulator(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DisassmbleSimulator)
{
    ui->setupUi(this);
}

DisassmbleSimulator::~DisassmbleSimulator()
{
    delete ui;
}
