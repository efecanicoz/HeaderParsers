#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtCore"
#include "QtGui"
#include <QMessageBox>
#include <disassmblesimulator.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionNew_triggered()
{
    QMessageBox::information(this, "title" ,"Hello");
}

void MainWindow::on_disassembleBut_clicked()
{

}

void MainWindow::on_actionSim_triggered()
{
   /* DisassmbleSimulator ds;
    ds.setModal(true);
    ds.exec();*/

    ds = new DisassmbleSimulator(this);
    ds->show();
}
