#ifndef DISASSMBLESIMULATOR_H
#define DISASSMBLESIMULATOR_H

#include <QMainWindow>

namespace Ui {
class DisassmbleSimulator;
}

class DisassmbleSimulator : public QMainWindow
{
    Q_OBJECT

public:
    explicit DisassmbleSimulator(QWidget *parent = 0);
    ~DisassmbleSimulator();

private:
    Ui::DisassmbleSimulator *ui;
};

#endif // DISASSMBLESIMULATOR_H
