#include "texteditor.h"
#include "ui_texteditor.h"
#include <QtCore/QString>
#include <QtCore/QFile>
#include <QtCore/QDebug>
#include <QtCore/QTextStream>
#include <QKeyEvent>

TextEditor::TextEditor(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TextEditor)
{
    ui->setupUi(this);
}

TextEditor::~TextEditor()
{
    delete ui;
}

void TextEditor::on_pushButton_clicked()
{
    QString s = ui->plainTextEdit->toPlainText();

    QFile file("/Users/firatsezel/Desktop/result.txt");
    file.open(QIODevice::WriteOnly);
    QDataStream out(&file);
    out << s;

    this->hide();
}

void TextEditor::keyPressEvent(QKeyEvent * event){

     if(event->key() == Qt::Key_Enter){
         QString s = ui->plainTextEdit->toPlainText();

         QFile file("/Users/firatsezel/Desktop/result.txt");
         file.open(QIODevice::WriteOnly);
         QDataStream out(&file);
         out << s;

         this->hide();
     }
}
