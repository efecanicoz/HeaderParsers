#ifndef SIMULATOR_H
#define SIMULATOR_H

#include <QMainWindow>
#include <texteditor.h>
#include <QTableView>
#include <QItemDelegate>
#include <QStandardItemModel>

namespace Ui {
class Simulator;
}

class Simulator : public QMainWindow
{
    Q_OBJECT

public:
    explicit Simulator(QWidget *parent = 0);
    ~Simulator();

private slots:
    void on_actionWrite_Assembly_triggered();

    void on_pushButton_2_clicked();

private:
    Ui::Simulator *ui;
    TextEditor *tx;
    QStandardItemModel *model;
    QStandardItemModel *model2;
};

#endif // SIMULATOR_H
