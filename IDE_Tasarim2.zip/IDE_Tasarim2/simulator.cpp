#include "simulator.h"
#include "ui_simulator.h"
#include <QtCore/QFile>
#include <QtCore/QDebug>
#include <QtCore/QTextStream>
#include <QMessageBox>

Simulator::Simulator(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Simulator)
{

    ui->setupUi(this);

    QFile file("/Users/firatsezel/Desktop/result.txt");
    if(!file.open(QIODevice::ReadOnly))
       QMessageBox::information(0,"info", "error");

    QTextStream in(&file);

    ui->textBrowser_4->setText(in.readAll());

    model = new QStandardItemModel(11,2,this);
    model2 = new QStandardItemModel(11,2,this);


       // Attach the model to the view
       ui->model->setModel(model);
       ui->model2->setModel(model2);

       // Generate data
       for(int row = 0; row < 11; row++)
       {
           for(int col = 0; col < 2; col++)
           {
               QModelIndex index
                       = model->index(row,col,QModelIndex());
               model->setData(index,0);

               QModelIndex index2
                       = model2->index(row,col,QModelIndex());
               model2->setData(index2,0);
           }
       }

}

Simulator::~Simulator()
{
    delete ui;
}

void Simulator::on_actionWrite_Assembly_triggered()
{
    tx = new TextEditor(this);
    tx->show();
}

void Simulator::on_pushButton_2_clicked()
{
    QFile file("/Users/firatsezel/Desktop/result.txt");
    if(!file.open(QIODevice::ReadOnly))
       QMessageBox::information(0,"info", "error");

    QTextStream in(&file);

    ui->textBrowser_4->setText(in.readAll());
}
