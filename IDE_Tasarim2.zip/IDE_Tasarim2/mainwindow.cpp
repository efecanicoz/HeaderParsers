#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    sm = new Simulator(this);
    sm->show();
}

void MainWindow::on_toolButton_clicked()
{
    QString file1Name = QFileDialog::getOpenFileName(this,
             tr("Open Executable"), "/");//dosyayi cek

    ui->textEdit->setText(file1Name);//pathi yazdir

    std::string param = file1Name.toUtf8().constData();//qstring to string

    QString qstr = QString::fromStdString(::readFile(param));//string to qstring

    Elf64 elf(param);
    elf.readIdent();
    elf.readHeader();
    elf.readSectionHeaders();
    std::vector<std::string> secNames = elf.getSectionNames();

    for(int i = 0; i < secNames.size(); i++){
        ui->SecNamecomboBox->addItem( QString::fromStdString(secNames[i]));
    }

}

void MainWindow::on_pushButton_2_clicked()
{
    std::vector<uint8_t> secCont = elf.getSectionContent(ui->SecNamecomboBox->currentText().toUtf8().constData());

    for(int i = 0; i < secCont.size(); i++){
        ui->textBrowser_2->setText(QString::fromStdString(secCont[i]));
    }

}
