#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "reader.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString title = ui->comboBox->currentText();
    ui->textBrowser_2->clear();
    ui->textBrowser_2->setText(title);
}
